***********
MrPong v1.0
***********
Created by Mrcool4.

Developed on Windows with Python 2.6 and Pygame 1.9.

To run simply double-click on MrPong 1.0.py

W and S control the left paddle, Up and Down arrows control the right.
Press p to pause/unpause the game.

The winner is the first player to score 21.

Licensed under the GNU General Public License.
See COPYING.txt for more.

Feedback should be sent to mrcool4.0b@gmail.com and is very much appreciated!!

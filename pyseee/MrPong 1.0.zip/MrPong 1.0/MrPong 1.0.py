#! /usr/bin/env python

##########################################################################
# MrPong V1.0
# Created by Mrcool4 in Python v2.6 and Pygame v.1.9 on Windows XP.
#
# Thanks to Pymike for his excellent rect collision tutorial on which this
# game is based. Thanks also to Pedros for helping me past some initial
# hurdles ;)
#
#    Copyright (C) 2009  Mrcool4
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Feedback to mrcool4.0b@gmail.com or on www.pygame.org
##########################################################################

import os
import random
import sys
import pygame
from menu import Menu

screen_width = 320
screen_height = 240

if sys.platform == ('win32' or 'win64'):
    os.environ["SDL_VIDEO_CENTERED"] = "1"
screen = pygame.display.set_mode((320, 240))

player_width = 8
player_height = 28

ball_width = 6
ball_height = 6

score1 = 0
score2 = 0
winning_score = 21

speed = 60

menufont = os.path.join("Fonts", "MINYNB__.ttf")
gamefont = os.path.join("Fonts", "BitstreamVeraSans.ttf")

# This is a simple function to draw text to the screen
def write(font, size, text, colour, position=(0, 0), centeredX=False, centered=False, SysFont=False):
    """The centeredX argument only centers the text on the x axis when True.
    The centered argument places the center of the text in the center of the
    screen when True. The SysFont argument use pygame.font.SysFont when True and
    pygame.font.Font when False"""

    if SysFont == True:
        fontimg = pygame.font.SysFont(font, size)
    else:
        fontimg = pygame.font.Font(font, size)
    textimg = fontimg.render(str(text), True, colour)
    if centeredX == True:
            width = textimg.get_width()
            xPosition = position[1]
            position = (((screen_width/2) - (width/2)), xPosition)
            screen.blit(textimg, position)
    if centered == True:
            width = textimg.get_width()
            height = textimg.get_height()
            position = (((screen_width/2) - (width/2)), ((screen_height/2) - (height/2)))
            screen.blit(textimg, position)
    else:
        screen.blit(textimg, position)

def main_menu(winner=None):
    mainmenu = Menu(
        [menufont, "New Game", 40, (255,255,255), (0,200,255),
         (0,(screen_height/2 - 75)), main],
        [menufont, "Instructions", 40, (255,255,255), (0,200,255),
         (0, (screen_height/2 - 18)), instructions_menu],
        [menufont, "Quit", 40, (255,255,255), (0,200,255),
         (0,(screen_height/2 + 40)), Quit])

    mainmenu_running = True
    while mainmenu_running:
        clock.tick(speed)

        mainmenu.update()

        screen.fill((0, 0, 0))

        mainmenu.draw(screen, True)
        if winner == 1:
            p1win = "Player 1 wins!"
            write(menufont, 32, p1win, (255, 255, 0), (0,0), True)
        if winner == 2:
            p2win = "Player 2 wins!"
            write(menufont, 32, p2win, (255, 255, 0), (0,0), True)

        pygame.display.update()

def instructions_menu():
    imenu = Menu(
        [menufont, "Back", 30, (255,255,255), (0,200,255),
         (0,(screen_height/2 + 20)), main_menu],
        [menufont, "Quit", 30, (255,255,255), (0,200,255),
         (0,(screen_height/2 + 70)), Quit])

    imenu_running = True
    while imenu_running:
        clock.tick(speed)

        imenu.update()

        screen.fill((0, 0, 0))

        imenu.draw(screen, True)
        l1 = "W and S control the left paddle,"
        l21 = "Up and Down arrows control"
        l22 = "the right paddle"
        l3 = "The first player to 21 wins"
        l4 = "Press p to pause/unpause the game"
        write(menufont, 18, l1, (255, 255, 0), (0,0), True)
        write(menufont, 18, l21, (255, 255, 0), (0,30), True)
        write(menufont, 18, l22, (255, 255, 0), (0,50), True)
        write(menufont, 18, l3, (255, 255, 0), (0,80), True)
        write(menufont, 18, l4, (255, 255, 0), (0,110), True)

        pygame.display.update()

def Quit():
    sys.exit()

class Player(object):
   
   
    def __init__(self,rect):
        self.rect = rect
       
        # Add each new player to players list
        players.append(self)

    def move(self, dy):   

        # Call __move() for the y axis.
        if dy != 0:
            self.__move(dy)
       
    def __move(self, dy):
           
        # Move the rect
        self.rect.y += dy

        # If you collide with a wall, move out based on velocity
        for wall in walls:
            if self.rect.colliderect(wall.rect):
                if dy > 0: # Hit the top side of the wall
                    self.rect.bottom = wall.rect.top
                if dy < 0: # Hit the bottom side of the wall
                    self.rect.top = wall.rect.bottom

class Ball(object):

    def __init__(self, rect):
        self.rect = rect
       
        # Inital direction for the ball
        choices = [-2, 2]
        self.xspeed = random.choice(choices)
        self.yspeed = random.choice(choices)
           
    def move(self, dx, dy):
       
        if dx != 0:
            self.__move(dx, 0)
        if dy != 0:
            self.__move(0, dy)
       
   
    def __move(self, dx, dy):
       
        # Move the rect
        self.rect.x += dx
        self.rect.y += dy

        global score1
        global score2
        global speed
        # If ball collides with a wall, change direction
        for wall in walls:
            if self.rect.colliderect(wall.rect):
                if dx > 0: # Moving right; Hit the left side of the wall
                    self.rect.right = wall.rect.left
                    self.xspeed = -self.xspeed
                    score1 += 1 # Changes the scoreboard
           
                if dx < 0: # Moving left; Hit the right side of the wall
                    self.rect.left = wall.rect.right
                    self.xspeed = -self.xspeed
                    score2 += 1 # Changes the scoreboard
           
                if dy > 0: # Moving down; Hit the top side of the wall
                    self.rect.bottom = wall.rect.top
                    self.yspeed = -self.yspeed
               
                if dy < 0: # Moving up; Hit the bottom side of the wall
                    self.rect.top = wall.rect.bottom
                    self.yspeed = -self.yspeed
       
        # if ball collides with a player, change direction
        for p in players:
            if self.rect.colliderect(p.rect):
                speed += 1
                if dx > 0: # Moving right; Hit the left side of the wall
                    self.rect.right = p.rect.left
                    self.xspeed = -self.xspeed
           
                if dx < 0: # Moving left; Hit the right side of the wall
                    self.rect.left = p.rect.right
                    self.xspeed = -self.xspeed
           
                if dy > 0: # Moving down; Hit the top side of the wall
                    self.rect.bottom = p.rect.top
                    self.yspeed = -self.yspeed
               
                if dy < 0: # Moving up; Hit the bottom side of the wall
                    self.rect.top = p.rect.bottom
                    self.yspeed = -self.yspeed
               
class Wall(object):
       
    def __init__(self, pos, colour):
        walls.append(self)
        self.colour = colour
        self.rect = pygame.Rect(pos[0], pos[1], 16, 16)

# Initialise pygame
pygame.init()

# Set up the display
pygame.display.set_caption("MrPong 1.0")

clock = pygame.time.Clock()

players = []
walls = []

player1 = Player(pygame.Rect(25, ((screen_height/2)-(player_height/2)), player_width, player_height)) # Create player 1
player2 = Player(pygame.Rect((screen_width-25-player_width), ((screen_height/2)-(player_height/2)),
                             player_width, player_height)) # Create player 2
ball = Ball(pygame.Rect((screen_width/2), (screen_height/2), ball_width, ball_height)) # Create the ball

# The level layout
level = [
"WWWWWWWWWWWWWWWWWWWW",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"L                  L",
"WWWWWWWWWWWWWWWWWWWW",
]

x = y = 0
for row in level:
    for col in row:
        if col == "W":
            Wall((x, y), (255, 255, 255))
        if col == "L":
            Wall((x, y), (0, 0, 255))
        x += 16
    y += 16
    x = 0

def main():
    global score1
    global score2
    global speed

    init_run = False
    gamepaused = False                
    playgame = True

    while playgame:
        # The fps   
        clock.tick(speed)

        # If a player wins, go to the main menu and print which player won
        if score1 == winning_score:
            ball.rect.topleft = ((screen_width/2), (screen_height/2))
            player1.rect.topleft = (25, ((screen_height/2)-(player_height/2)))
            player2.rect.topleft = ((screen_width-25-player_width), ((screen_height/2)-(player_height/2)))
            score1 = 0
            score2 = 0
            speed = 60
            main_menu(1)
        if score2 == winning_score:
            ball.rect.topleft = ((screen_width/2), (screen_height/2))
            player1.rect.topleft = (25, ((screen_height/2)-(player_height/2)))
            player2.rect.topleft = ((screen_width-25-player_width), ((screen_height/2)-(player_height/2)))
            score1 = 0
            score2 = 0
            speed = 60
            main_menu(2)
                  
        # Handle keyboard input not to do with movement of players
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                Quit()
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                Quit()
            if e.type == pygame.KEYDOWN and e.key == pygame.K_p:
                gamepaused = True

        # Pause the game
        while gamepaused:
            clock.tick(speed)
            write(gamefont, 26, "Game paused", (255,255,255), (0, (screen_height/2)-12), True)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    Quit()
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    Quit()
                if e.type == pygame.KEYDOWN and e.key == pygame.K_p:
                    gamepaused = False
            pygame.display.update()
           
        # Move the player if an arrow key is pressed
        key = pygame.key.get_pressed()
        if key[pygame.K_UP]:
            player2.move(-2)
        if key[pygame.K_DOWN]:
            player2.move(2)
        if key[pygame.K_w]:
            player1.move(-2)
        if key[pygame.K_s]:
            player1.move(2)

        # Move the ball
        ball.move(ball.xspeed, ball.yspeed)
           
        # Draw the scene
        screen.fill((0, 0, 0))

        # Draw the walls   
        for wall in walls:
            pygame.draw.rect(screen, (wall.colour), wall.rect)       

        # Draws the players and the ball   
        pygame.draw.rect(screen, (255, 200, 0), player1.rect)
        pygame.draw.rect(screen, (255, 200, 0), player2.rect)
        pygame.draw.rect(screen, (255, 0, 0), ball.rect)

        # Draws the scoreboard and speed
        scoreboard = (str(score1)) + "-" + (str(score2))
        ballspeed = "Current speed:" + str(speed - 59)
        write(gamefont, 16, scoreboard, (0, 0, 0), (0, 0), True)
        write(gamefont, 16, (str(ballspeed)), (0, 0, 0), (0, (screen_height-18)), True)

        pygame.display.update()

        # Delays the start of the game by one second so players are ready
        if not init_run:
            pygame.time.wait(1000)
            init_run = True

# Start the game
if __name__ == "__main__":
    main_menu()

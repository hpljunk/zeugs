##########################################################################
# Simple Menu Module
# Created by Mrcool4 in Python v2.6 and Pygame v.1.9 on Windows XP.
#
#    Copyright (C) 2009  Mrcool4
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Feedback to mrcool4.0b@gmail.com or on pygame.org
##########################################################################

import pygame
import sys

class Menu:

    def __init__(self, *options): # The * symbol expands the list
        """You must pass the options in a list in the form:
        [font, text, size, normalcolour, highlightedcolour, position, function it
        returns if selected]"""
        self.options = options
        self.focus = 1 # This is the option currently selected in the menu

    def draw(self, surface, centered=False):
        """The 'centered' argument here will only center the text along the x
        axis. The y coordinate passed in the position argument in self.options
        will still be used for the y position"""
        i = 1
        for n in self.options: # Iterates over all options and blits them to the chosen surface 
            if i == self.focus:
                colour = n[4]
            else:
                colour = n[3]
            font = pygame.font.Font(n[0], n[2])
            text = n[1]
            img = font.render(text, True, colour)
            if centered == True:
                width = img.get_width()
                position = n[5][1]
                surface_width = surface.get_width()
                position = (((surface_width/2) - (width/2)), n[5][1])
                surface.blit(img, position)
            else:
                position = n[5]
                surface.blit(img, position)

            i += 1

    def update(self, orientation="vertical"):
        """Menu can be either 'horizontal'(controlled by right/left arrows),
        or 'vertical'(controlled by up/down arrows). Default is vertical."""
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                sys.exit()
            if e.type == pygame.KEYDOWN:
                if orientation == "vertical":
                    if e.key == pygame.K_UP:
                        self.focus -= 1
                    if e.key == pygame.K_DOWN:
                        self.focus += 1
                if orientation == "horizontal":
                    if e.key == pygame.K_LEFT:
                        self.focus -= 1
                    if e.key == pygame.K_RIGHT:
                        self.focus += 1
                if e.key == pygame.K_ESCAPE:
                    sys.exit()
                if e.key == pygame.K_RETURN:
                    self.options[self.focus-1][6]() # Returns function of currently selected option                    
        if self.focus > len(self.options):
            self.focus = 1 # Focuses on top of menu if player presses down on bottom option
        if self.focus < 1:
            self.focus = len(self.options) # Focuses on bottom of menu if player presses up on top option
